import pandas as pd
import numpy as np
# --- 1. CONFIGURACIÓN GLOBAL (¡CORREGIDA!) ---
# Nombres de las columnas de tu Excel (Estos están correctos)
COL_GENERO = "F1"
COL_EDAD_EXACTA = "F2_num"
COL_CIUDAD = "F3"
COL_NSE = "ESTRATO_MEX"
COL_SEGMENTO = "segmento"
COL_OCASION = "actividad"
COL_FILTRO_JUGOS = "F6_5"
COL_FILTRO_ISOTONICAS = "F6_1"

# Rutas de tus archivos (Aquí estaba el error, ahora está corregido)
BASE_DIR = r"C:\Users\Ronah\OneDrive\Escritorio\Livepanel PPS\trabajo sobre hydratation"
RUTA_DATOS = f"{BASE_DIR}\\Copia de Hydration_Train_Codes_Light.xlsx - Hoja1.csv"
RUTA_SALIDA_FINAL = f"{BASE_DIR}\\MUESTRA_FINAL_100_CASOS.xlsx"

# Mapeo de columnas de datos (Esto está correcto)
MAPEO_COLUMNAS_CUOTA = {
    COL_GENERO: 'Género',
    'Edad_Agrupada': 'Edad', # Esta la creamos nosotros
    COL_CIUDAD: 'Ciudad',
    COL_NSE: 'NSE',
    COL_OCASION: 'Ocasión de consumo',
    COL_SEGMENTO: 'Segmento (casos mínimos)'
}

# --- 2. LÍMITES DE CUOTAS (Están dentro del script) ---

LIMITES_JUGOS = {
    'Género': {'Hombre': 24, 'Mujer': 26},
    'Edad': {'19-25': 8, '26-35': 14, '36-45': 13, '46-55': 10, '56-65': 5},
    'Ciudad': {'Ciudad de México y Área Metropolitana': 22, 'Guadalajara': 13, 'Monterrey': 15},
    'NSE': {'AB': 11, 'C+': 18, 'C': 7, 'C-': 11, 'D+': 0, 'D': 4},
    'Ocasión de consumo': {'SPORT': 4, 'PHYSICAL': 17, 'PASSIVE': 29},
    'Segmento (casos mínimos)': {
        'Competitive Athlete': 7, 'Light Competitive': 6,
        'Fitness Excerciser': 15, 'Active Lifestyles': 6, 'Inactives': 16
    }
}

LIMITES_ISOTONICAS = {
    'Género': {'Hombre': 26, 'Mujer': 24},
    'Edad': {'19-25': 7, '26-35': 16, '36-45': 15, '46-55': 9, '56-65': 3},
    'Ciudad': {'Ciudad de México y Área Metropolitana': 27, 'Guadalajara': 13, 'Monterrey': 10},
    'NSE': {'AB': 17, 'C+': 9, 'C': 4, 'C-': 19, 'D+': 0, 'D': 1},
    'Ocasión de consumo': {'SPORT': 21, 'PHYSICAL': 13, 'PASSIVE': 16},
    'Segmento (casos mínimos)': {
        'Competitive Athlete': 15, 'Light Competitive': 13,
        'Fitness Excerciser': 7, 'Active Lifestyles': 5, 'Inactives': 10
    }
}

# --- 3. FUNCIONES DE AGRUPACIÓN (Solo necesitamos la de Edad) ---

def agrupar_edad(edad):
    try:
        edad = int(edad) # Asegurarse de que sea un número
        if edad > 65: return "Más de 65 años"
        if edad >= 56: return "56-65"
        if edad >= 46: return "46-55"
        if edad >= 36: return "36-45"
        if edad >= 26: return "26-35"
        if edad >= 19: return "19-25"
        return "Menos de 19 años"
    except (ValueError, TypeError):
        return "Edad Inválida"

# --- 4. FUNCIÓN PRINCIPAL DE SELECCIÓN ---
def seleccionar_cuota(df_principal, col_filtro_bebida, n_muestra, limites_dict, nombre_proceso):
    
    print(f"\n--- Iniciando proceso para: {nombre_proceso} ---")
    
    # --- 4a. Filtrar y preparar datos
    # Convertir la columna de filtro a número, forzando errores a NaN
    df_principal[col_filtro_bebida] = pd.to_numeric(df_principal[col_filtro_bebida], errors='coerce')
    # Filtramos donde la columna (ej: F6_5) sea igual a 1
    df_filtrado = df_principal[df_principal[col_filtro_bebida] == 1].copy()
    
    if len(df_filtrado) == 0:
        print(f"Advertencia: No se encontró ningún caso con valor '1' en la columna '{col_filtro_bebida}'.")
        return pd.DataFrame() # Devuelve un DataFrame vacío

    print(f"Se encontraron {len(df_filtrado)} casos de '{nombre_proceso}'.")

    # --- 4b. Crear columna de Edad Agrupada
    try:
        df_filtrado['Edad_Agrupada'] = df_filtrado[COL_EDAD_EXACTA].apply(agrupar_edad)
    except KeyError as e:
        print(f"Error fatal: No se encontró la columna de Edad: {e}")
        return pd.DataFrame()
        
    # --- 4c. Aleatorizar
    df_shuffled = df_filtrado.sample(frac=1, random_state=42).reset_index(drop=True)

    # --- 4d. Preparar Contadores
    contadores = { var: {cat: 0 for cat in cats} for var, cats in limites_dict.items() }

    # --- 4e. El Algoritmo de Selección (Greedy)
    indices_seleccionados = []
    print("Iniciando selección de casos...")

    for index, row in df_shuffled.iterrows():
        if len(indices_seleccionados) >= n_muestra:
            break

        cabe_en_cuota = True
        atributos_de_esta_fila = []

        try:
            for col_excel, var_cuota in MAPEO_COLUMNAS_CUOTA.items():
                valor_fila = row[col_excel]

                if isinstance(valor_fila, str):
                    valor_fila = valor_fila.strip()

                if var_cuota in limites_dict:
                    if valor_fila in limites_dict[var_cuota]:
                        limite_actual = limites_dict[var_cuota][valor_fila]
                        conteo_actual = contadores[var_cuota][valor_fila]

                        if conteo_actual >= limite_actual:
                            cabe_en_cuota = False
                            break
                        else:
                            atributos_de_esta_fila.append((var_cuota, valor_fila))
                    else:
                        # Si el valor (ej. una ciudad no listada) no está en las cuotas, se rechaza.
                        cabe_en_cuota = False
                        break
        except KeyError as e:
            print(f"Error de Mapeo: La columna '{e}' no se encontró en los datos de la fila.")
            cabe_en_cuota = False

        if cabe_en_cuota:
            indices_seleccionados.append(index)
            for var, cat in atributos_de_esta_fila:
                contadores[var][cat] += 1

    # --- 4f. Devolver resultado
    df_muestra_final = df_shuffled.loc[indices_seleccionados]
    print(f"Proceso '{nombre_proceso}' completado. {len(df_muestra_final)} casos seleccionados.")
    
    for var, cats in contadores.items():
        print(f"  --- {var} ---")
        for cat, conteo in cats.items():
            limite = limites_dict[var][cat]
            print(f"    {cat}: {conteo} de {limite}")
            
    return df_muestra_final

# --- 5. EJECUCIÓN PRINCIPAL ---
if __name__ == "__main__":
    
    print("Cargando base de datos principal...")
    try:
        # Intentar detectar la codificación correcta
        df_data = pd.read_csv(RUTA_DATOS, encoding='utf-8')
    except UnicodeDecodeError:
        print("UTF-8 falló, intentando con 'latin1'...")
        try:
            df_data = pd.read_csv(RUTA_DATOS, encoding='latin1')
        except Exception as e:
            print(f"Error fatal: No se pudo leer el archivo de datos principal: {RUTA_DATOS}")
            print(e)
            exit()
            
    print(f"Datos cargados. {len(df_data)} filas totales.")

    # --- Ejecutar para JUGOS
    df_resultado_jugos = seleccionar_cuota(
        df_principal=df_data,
        col_filtro_bebida=COL_FILTRO_JUGOS, # <-- Usa F6_5
        n_muestra=50,
        limites_dict=LIMITES_JUGOS,
        nombre_proceso="JUGOS"
    )
    
    # --- Ejecutar para ISOTÓNICAS
    df_resultado_isotonicas = seleccionar_cuota(
        df_principal=df_data,
        col_filtro_bebida=COL_FILTRO_ISOTONICAS, # <-- Usa F6_1
        n_muestra=50,
        limites_dict=LIMITES_ISOTONICAS,
        nombre_proceso="ISOTÓNICAS"
    )

    # --- Escribir el archivo Excel final con DOS hojas
    print(f"\nEscribiendo archivo final en: {RUTA_SALIDA_FINAL}")
    try:
        with pd.ExcelWriter(RUTA_SALIDA_FINAL) as writer:
            df_resultado_jugos.to_excel(writer, sheet_name='Jugos_50_Casos', index=False)
            df_resultado_isotonicas.to_excel(writer, sheet_name='Isotonicas_50_Casos', index=False)
        
        print("\n--- ¡PROCESO TOTALMENTE COMPLETADO! ---")
        print(f"Se ha guardado el archivo '{RUTA_SALIDA_FINAL}' con dos hojas.")
        
    except Exception as e:
        print(f"Error al guardar el archivo Excel final: {e}")
        print("Asegúrate de no tener el archivo 'MUESTRA_FINAL_100_CASOS.xlsx' abierto.")